define([
    'Magento_Ui/js/form/element/region'
], function(Component) {
    return Component.extend({
        
    });
});
