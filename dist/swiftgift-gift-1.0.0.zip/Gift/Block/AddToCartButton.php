<?php
namespace Swiftgift\Gift\Block;

class AddToCartButton extends \Swiftgift\Gift\Block\ElementBase {
    
}
