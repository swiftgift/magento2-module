<?php
namespace Swiftgift\Gift\Block;

class SwiftGiftCheckoutProcessButton extends \Swiftgift\Gift\Block\ElementBase {
    
}
