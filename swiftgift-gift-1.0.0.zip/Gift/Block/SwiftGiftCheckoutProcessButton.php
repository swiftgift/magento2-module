<?php
namespace Swiftgift\Gift\Block;

class SwiftGiftCheckoutProcessButton extends \Magento\Framework\View\Element\Template {
    
}