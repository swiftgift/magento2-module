define(['ko', 'underscore'], function(ko, _) {
    return function(target) {
        return target;
    };
});
